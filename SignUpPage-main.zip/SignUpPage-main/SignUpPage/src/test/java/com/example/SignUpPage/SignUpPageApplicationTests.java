package com.example.SignUpPage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SignUpPageApplicationTests {

	@Test
	void contextLoads() {
	}

}
